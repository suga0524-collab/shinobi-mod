# Warfare-Expanded-Reworked
A massive unit expansion mod for Unciv G&amp;K Ruleset, with some adjustments, such as:                                                                                                       Redcoat unique unit for England, 
 Sturmtruppen unique unit for Germany,
 Imperial Guard unique unit for France and 
 Brazilian Portuguese translation. 
 More may come in the future.



